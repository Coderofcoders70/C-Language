#include <stdio.h>

int main()
{
    //simple sum value 
    // int i = 0, n, sum = 0;

    // printf("Enter the value for series: ");
    // scanf("%d", &n);
    // with for loop
    // for (i = 0; i <= n; i++)
    // {
    //     sum = sum + i;
    // }
    // printf("sum of value %d is %d", n,sum); 

    // with while loop
    // while(i <= n)
    // {
    //     sum = sum + i;
    //     i++;
    // }
    // printf("sum of value %d is %d", n, sum);
    return 0;
}