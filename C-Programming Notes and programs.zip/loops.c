#include <stdio.h>

int main()
{
    // WHILE LOOP
    
    // int a;

    // printf("Enter the value: ");
    // scanf("%d", &a);

    // while (a <= 10)
    // {
    //     printf("Value: %d\n", a);   //FINITE LOOP
    //     a++;
    // }

    // while (a > 10)                  //INFINITE LOOP
    // {
    //     printf("Value: %d\n", a);
    //     a++;
    // }

    // ********Increment and Decrement Operator*********
    // Postfix:-
    // NOTE:- Pehle value assign hogi phir increment hoga
    // int i = 0; 

    // printf("Value of i %d\n", i++); 
    // printf("Value of i %d\n", i);
    // Output:-
    // Value of i 0 
    // Value of i 1

    // Postfix:-
    // NOTE:- Pehle value increment hogi phir value assign hogi
    // printf("Value of i %d\n", ++i);
    // printf("Value of i %d", i);
    // Output:-
    // Value of i 1 
    // Value of i 1

    // ______DO WHILE LOOP______
    // int i = 0;

    // do
    // {
    //     printf("%d\n", i);
    //     i++;
    // } while (i <= 10);


    // ______FOR LOOP______
    // int i = 0;

    // for(i = 0; i <= 10; i++)
    // {
    //     printf("%d\n", i);
    // }

    // Decrement using for loop
    // int i;

    // for(i = 5; i; i--) // i will be read as 0 in the condition statement.
    // {
    //     printf("%d\n", i);
    // }

    // *******Break and Continue statement**********
    // int i = 0;

    // Break statement:-
    // for (i = 0; i < 10; i++)
    // {
    //     if (i == 5)
    //     {
    //         break;
    //     }
    //     printf("%d\n", i);
    // }
    
    // Continue statement:-
    // for (i = 0; i < 10; i++)
    // {
    //     if (i == 5)
    //     {
    //         continue;
    //     }
    //     printf("%d\n", i);
    // }
        
    return 0;
}