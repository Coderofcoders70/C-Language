#include <stdio.h>

int main()
{
    /*  Ques) Write a program to find grade of a student given his marks based on below:-
        100-90 -> A
        90-80 -> B
        80-70 -> C
        70-60 -> D
        60-50 -> E
    */ 
    
    // int marks, range;

    // printf("Enter your marks: ");
    // scanf("%d", &marks);
    // printf("\n");
    // printf("Enter 1. If range is 100 - 90 \n");
    // printf("Enter 2. If range is 90 - 80 \n");
    // printf("Enter 3. If range is 80 - 70 \n");
    // printf("Enter 4. If range is 70 - 60 \n");
    // printf("Enter 5. If range is 60 - 50 \n\n");
    // printf("Enter range: ");
    // scanf("%d", &range);
     
    // printf("\n");
    // switch (range)
    // {
    // case 1:
    //     printf("Marks: %d Congratulations your grade is A !!", marks);
    //     break;
    // case 2:
    //     printf("Marks: %d Well Done your grade is B !!", marks);
    //     break;
    // case 3:
    //     printf("Marks: %d Good your grade is C !!", marks);
    //     break;
    // case 4:
    //     printf("Marks: %d Umm nice but try more your grade is D !!\n", marks);
    //     printf("Work Hard my friend");
    //     break;
    // case 5:
    //     printf("Marks: %d Noo this is really bad your grade is F !!\n", marks);
    //     printf("Work Very Hard my friend");
    //     break;
    
    // default:
    //     printf("Soryy You failed !!");
    //     break;
    // }

    // Another method to solve the same question
    // int marks;

    // printf("Enter marks: ");
    // scanf("%d", &marks);

    // if(marks < 0 || marks > 100)  It is an optional condition
    // {
    //     printf("Invalid Marks!!");
    // }

    // switch (marks/10)
    // {
    // case 10:
    //     printf("Grade A");
    //     break;
    // case 9:
    //     printf("Grade A");
    //     break;
    // case 8:
    //     printf("Grade B");
    //     break;
    // case 7:
    //     printf("Grade C");
    //     break;
    // case 6:
    //     printf("Grade D");
    //     break;
    // case 5:
    //     printf("Grade E");
    //     break;
    
    // default:
    //     printf("Fail !! Work Hard");
    //     break;
    // }
    // return 0;
}