#include <stdio.h>

int main(void)
{
    printf("Hello world!\r");
    /* The term '\r' above is known as "Carriage return" which means 
    it will return the cursor again to the beginning of the
    line. */
    printf("Good morning!\n");
    printf("Heyy");
    return 0;
}