#include <stdio.h>

int main()
{
    /*
        Ques. Print the following number pyramid pattern:-

           1
          123
         12345
        1234567
    */
    
    int n;

    printf("Enter the number: ");
    scanf("%d", &n);

    int a = 1;
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n - i; j++)
        {
            printf(" ");
        }
        for (int k = 1; k <= a; k++)
        {
            printf("%d", k);
        }
        a = a + 2;
        printf("\n");
    }
    
    return 0;
}