#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    // int rNum, guess, attempt;
    // char ans;
    
    // printf("\n***GUESS THE NUMBER GAME***\n");
    // printf(" ***Welcome to the Game***\n\n");
    // printf("Are you ready to play this exciting game?\n");
    // printf("Press Y for yes and N for No: ");
    // scanf("%c", &ans);
   
    // if (ans == 'y' || ans == 'Y')
    // {
    //     printf("\nLet's understand the Instructions first:-\n");
    //     printf("1. --> You have to guess the number between 1 to 100.\n");
    //     printf("2. --> If you will type higher number then you will get a message 'Don't go too High !!'\n");
    //     printf("3. --> If you will type lower number then you will get a message 'Nahh too Low!!'\n");
    //     printf("4. --> You will only get 10 attempts and you have to guess in those attempts only.\n");
    //     printf("5. --> Once you have read all the rules properly then you are good to go.\n\n");
    //     printf("Let's Play\n\n");
    //     srand(time(0));
    //     rNum = rand() % 100;
    //     // printf("Random Number is: %d\n", rNum);
        
    //     for (attempt = 1; attempt <= 10; attempt++)
    //     {
    //         printf("Guess the number: ");
    //         scanf("%d", &guess);
            
    //         if (guess < rNum)
    //         {
    //             printf("Nahh too Low!!\n");
    //         }
    //         else if (guess > rNum)
    //         {
    //             printf("Don't Go too High!!\n");
    //         }
    //         else if(guess == rNum)
    //         {
    //             printf("Hurray You Won !!\n");
    //             break;
    //         }            
    //     }
    //     printf("Total attempts: %d", attempt);
    // }
    // else
    // {
    //     printf("You are good for nothing\n");
    //     printf("Don't waste your time and get lost....\n");
    // }
    // return 0;
}