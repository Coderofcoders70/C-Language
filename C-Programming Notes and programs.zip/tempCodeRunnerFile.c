int main()
// {
//     // *********************CONVENIENT WAY TO PRINT A STRING*************
//     char *ptr = "LAKSHAYA";
//     printf("%s", ptr);
//     return 0;
// }