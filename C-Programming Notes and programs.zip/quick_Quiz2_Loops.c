#include <stdio.h>

int main()
{
    /* Ques. Write a program to print natural numbers from 10 to 20 when initial loop counter 
       is initialized to 0 ?
    */
    // int i = 0;
    // MY METHOD
    // printf("Enter value for i: ");
    // scanf("%d", &i);
   
    // printf("Enter value for a: ");
    // scanf("%d", &a);

    // printf("\nNatural numbers from 10 to 20 are:\n");
    // while (i <= a)
    // {
    //     printf("%d\n", i);
    //     i++;
    // }

    // Harry's Method

    // printf("Value of i is between 10 to 20:-\n");
    // while (i <= 20)
    // {
    //     if(i >= 10)
    //     {
    //         printf("Value: %d\n", i);
    //     }
    //     i++;
    // }

    // Ques. Write a program to print first n natural numbers using do-while loop? 
    // int i = 1, n = 5; Hard coded
    // int i = 0, n;

    // printf("Enter value: ");
    // scanf("%d", &n);
    
    // do
    // {
    //     printf("%d\n", i);
    //     i++;
    // } while (i <= n);   
    
    // Ques. Write a program to print first n natural numbers using do-while loop?
    // int i, n;

    // printf("Enter value: ");
    // scanf("%d", &n);

    // for(i = 0 + 1; i <= n; i++)
    // {
    //     printf("%d\n", i);
    // }

    //Ques. Write a program to print first n natural numbers in reverse order?
    // int i, n;

    // printf("Enter value: ");
    // scanf("%d", &n);

    // for(i = n; i > 0; i--)
    // {
    //     printf("%d\n", i);
    // }
}